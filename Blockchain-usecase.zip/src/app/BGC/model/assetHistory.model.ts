//domain model
export class AssetHistory {
    //declaration
    constructor(public newEmployer: String, public comments: String, public timestamp: String, public reason: String) {


    }
}