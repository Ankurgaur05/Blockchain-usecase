export class Participant {
    constructor(public accountBal: string,
        public fName: string, 
        public accountNumber: string, 
        public lName: string,
        public por: string,
        public uid: string,
        public addrLine: string,
        public gender: string,
        public email: string,
        public dob: string,
        public phone: string,
        public zipCode: string,
        public maritialStatus: string,
        public city: string,
        public countryCode: string,
        public province: string) {

    }
}