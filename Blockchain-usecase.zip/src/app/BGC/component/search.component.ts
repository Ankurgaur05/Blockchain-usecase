import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../common/sharedservices/common.services';

@Component({
    selector: 'search-component',
    templateUrl: './search.componentview.html'
})

export class SearchComponent {
   
    uid: string;
    key: string;
   // asset = new Asset("", "", "", "", "", "", "", "");

    constructor(    
    ) { }

}
