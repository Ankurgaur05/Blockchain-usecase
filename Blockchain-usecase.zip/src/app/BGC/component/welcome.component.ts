//
import { Component } from '@angular/core';
import { Observable } from 'rxjs/Rx';

@Component({
    selector: 'welcome-component',
    templateUrl: './welcome.componentview.html'
})

export class WelcomeComponent {
    constructor() {

    }
}
